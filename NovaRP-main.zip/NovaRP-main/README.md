# NovaRP
The resource pack for [Nova](https://github.com/xenondevs/Nova)

# Translating

If you would like to help translate Nova, you can do so via [Crowdin](https://crowdin.com/project/novaplugin/)
